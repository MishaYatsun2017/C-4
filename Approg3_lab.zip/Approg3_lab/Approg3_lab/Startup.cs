﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Approg3_lab.Startup))]
namespace Approg3_lab
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
