﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Approg3_lab.Models;

namespace Approg3_lab.Controllers
{
    public class BookController : Controller
    {

        private static Books books = new Books();
        // GET: Book
        public ActionResult Index()
        {
            return View(books.booksList);
        }

        public ActionResult AddBook()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddBook(BookModels book)
        {
            books.CreateBook(book);
            return RedirectToAction("Index");
        }

        public ActionResult UpdateBook(int id)
        {
            return View(books.ShowBook(id));
        }
        [HttpPost]
        public ActionResult UpdateBook(BookModels bookModels)
        {
            if (ModelState.IsValid)
            {
                books.UpdateBook(bookModels);
            }
            return RedirectToAction("Index");
        }

        public ActionResult DeleteBook(int id)
        {
            return View(books.ShowBook(id));
        }
        [HttpPost]
        [ActionName("DeleteBook")]
        public ActionResult Delete_Book(int id)
        {
            if (ModelState.IsValid)
            {
                books.DeleteBook(id);
            }
            return RedirectToAction("Index");
        }

        public ActionResult DetailsBook(int id)
        {
            return View(books.ShowBook(id));
        }

    }
}